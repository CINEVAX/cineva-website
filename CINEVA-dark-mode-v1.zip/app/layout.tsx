import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "CINEVA — Make what you imagine",
  description: "A welcoming creative studio for cinematic AI images and films."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
