"use client";

import { useMemo, useState } from "react";

const styles = ["Cinematic realism", "Editorial", "Dreamlike", "Film still", "Product photography"];
const ratios = ["Portrait 2:3", "Landscape 16:9", "Square 1:1"];

export default function Home() {
  const [prompt, setPrompt] = useState("A cozy New York street at Christmas, light snow, warm shop windows, cinematic movie still");
  const [style, setStyle] = useState(styles[0]);
  const [ratio, setRatio] = useState(ratios[1]);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("Your creative space is ready.");
  const [history, setHistory] = useState<string[]>([]);

  const promptCount = useMemo(() => prompt.trim().length, [prompt]);

  function generatePreview() {
    if (!prompt.trim()) {
      setNotice("Add a description before creating your image.");
      return;
    }
    setBusy(true);
    setNotice("Prototype mode: connect an image model to generate real images.");
    setHistory((items) => [prompt.trim(), ...items].slice(0, 4));
    window.setTimeout(() => setBusy(false), 700);
  }

  return (
    <main className="shell">
      <header className="topbar">
        <a className="brand" href="#"><span className="brand-mark">✳</span> CINEVA</a>
        <nav><a href="#create">Create</a><a href="#gallery">Discover</a><a href="#about">About</a></nav>
        <button className="account" onClick={() => setNotice("Account sign-in will be added in the next milestone.")}>Sign in <span>↗</span></button>
      </header>

      <section className="hero">
        <div className="hero-copy">
          <div className="eyebrow"><span className="sparkle">✦</span> YOUR IMAGINATION, IN THE FRAME</div>
          <h1>Make something<br/><em>unforgettable.</em></h1>
          <p>A creative studio for cinematic images and the stories behind them. Start with a thought. Leave with a frame worth keeping.</p>
          <a className="hero-link" href="#create">Explore the studio <span>↓</span></a>
        </div>
        <div className="hero-art" aria-label="Abstract colorful cinematic artwork">
          <div className="art-orb orb-one"/><div className="art-orb orb-two"/><div className="art-orb orb-three"/>
          <div className="art-card"><span>SCENE Nº 001</span><strong>Every frame<br/>has a feeling.</strong><small>CINEVA CREATIVE STUDIO</small></div>
          <div className="art-sticker">CREATE<br/>YOUR<br/>WORLD ✳</div>
        </div>
      </section>

      <section className="workspace" id="create">
        <div className="section-heading"><div><div className="eyebrow">THE IMAGE STUDIO</div><h2>Bring your idea to life.</h2></div><span className="beta">EARLY PREVIEW</span></div>
        <div className="studio-grid">
          <div className="controls panel">
            <label htmlFor="prompt">Describe your image</label>
            <textarea id="prompt" value={prompt} onChange={(e) => setPrompt(e.target.value)} maxLength={1200} placeholder="A scene, a character, a feeling..."/>
            <div className="counter">{promptCount} / 1200</div>
            <div className="field-row">
              <div className="field"><label htmlFor="style">Visual direction</label><select id="style" value={style} onChange={(e) => setStyle(e.target.value)}>{styles.map(s => <option key={s}>{s}</option>)}</select></div>
              <div className="field"><label htmlFor="ratio">Aspect ratio</label><select id="ratio" value={ratio} onChange={(e) => setRatio(e.target.value)}>{ratios.map(r => <option key={r}>{r}</option>)}</select></div>
            </div>
            <button className="generate" onClick={generatePreview} disabled={busy}>{busy ? "Preparing…" : "✦  Create image"}</button>
            <p className="fineprint">No charge in this prototype. Real generation will be connected after model and hosting setup.</p>
          </div>
          <div className="preview panel">
            <div className="preview-top"><span>YOUR CANVAS</span><span>01 / 01</span></div>
            <div className="canvas">
              <div className="canvas-glow"/><div className="canvas-type"><span>CINEVA / VISUAL STUDY</span><strong>Your next<br/><i>favorite frame.</i></strong><small>IMAGINE WITHOUT LIMITS</small></div>
              <div className="canvas-orbit"/>
            </div>
            <div className="preview-bottom"><span>{notice}</span><span>{ratio}</span></div>
          </div>
        </div>
      </section>

      <section className="gallery" id="gallery">
        <div className="section-heading"><div><div className="eyebrow">YOUR CREATIVE HISTORY</div><h2>Ideas in progress.</h2></div><span className="muted">This session only</span></div>
        {history.length ? <div className="history">{history.map((item, i) => <article key={i}><span>0{i+1}</span><p>{item}</p><small>{style}</small></article>)}</div> : <div className="empty-state"><span>✳</span><p>Your first creations will show up here.</p><small>Try a prompt above to start your collection.</small></div>}
      </section>

      <footer id="about"><a className="brand" href="#"><span className="brand-mark">✳</span> CINEVA</a><span>Made for the makers, dreamers, and scene-stealers.</span><span>© 2026 CINEVA · Prototype</span></footer>
    </main>
  );
}
