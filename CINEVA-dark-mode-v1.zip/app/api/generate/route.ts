import { NextResponse } from "next/server";

// Secure server-side integration point for the future image model.
// This endpoint intentionally does not pretend to generate images yet.
export async function POST(request: Request) {
  const body = await request.json().catch(() => null);

  if (!body || typeof body.prompt !== "string" || !body.prompt.trim()) {
    return NextResponse.json({ error: "Please provide an image prompt." }, { status: 400 });
  }

  if (!process.env.IMAGE_PROVIDER_URL || !process.env.IMAGE_PROVIDER_KEY) {
    return NextResponse.json(
      {
        status: "not_configured",
        message: "CINEVA's image engine is not connected yet. Add a compatible provider in the server environment."
      },
      { status: 503 }
    );
  }

  // Provider-specific request handling will be implemented after a model is selected.
  // Keep API keys on the server; never expose them to browser code.
  return NextResponse.json(
    { status: "provider_adapter_needed", message: "The provider is configured, but its adapter still needs implementation." },
    { status: 501 }
  );
}
